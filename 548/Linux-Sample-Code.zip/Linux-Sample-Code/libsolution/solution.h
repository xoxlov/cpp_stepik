#ifndef __LIBSOLUTION__
#define __LIBSOLUTION__

int stringStat(const char *string, int multiplier, int *count);

#endif
