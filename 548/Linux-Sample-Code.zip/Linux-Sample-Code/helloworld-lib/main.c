#include "hello.h"

int main()
{
	hello_message("Vasya");
	return 0;
}
