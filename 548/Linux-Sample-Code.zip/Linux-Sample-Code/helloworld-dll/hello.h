#ifndef __HELLO__
#define __HELLO__
void hello_message(const char *name);
#endif
